//: Playground - noun: a place where people can play

import UIKit


//Declarations of the variables
var b = 10
var e = 3.0
var x:Double = 5
var a:Int = 22
let ab:Int = 23
let q = 11

//Optionals

var x1:Int?
print(x)

var x2 = 20
var x3:Int? = 30
//x2 + x3 // since x3 is not unwrapped
// to unwrap it use"!" instead of ?

var x4:Int!
x2 + x3!
print(x3 as Any)
print(x3!)

print( "the given number is \(x2)")





